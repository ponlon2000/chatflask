// // グローバル変数として currentKey を定義
// let currentKey = null;

class LoginHandler {

    static handleLogin() {
      var id = $("#id").val();
      var password = $("#password").val();

      // Validate the id and password fields.
      if (id === "") {
        alert("IDを入力してください");
        return;
      }

      if (password === "") {
        alert("パスワードを入力してください");
        return;
      }

      $("#waiting").removeClass("hidden");

      // Send the id and password to the `/authorize` URL using an Ajax post request.
      $.ajax({
        url: "/authorize",
        method: "post",
        contentType: 'application/json',
        dataType: 'json',
        data: JSON.stringify({
          id: id,
          password: password
        }),
        success: function(response) {
          $("#waiting").addClass("hidden");
          // Add the id and password to the browser's local storage.
          if(response["result"] != "success") {
            alert("ユーザIDやパスワードが間違っています、もう一度ログインしてください");
            return;
          }
          window.localStorage.setItem("id", id);
          window.localStorage.setItem("password", password);

          // Redirect the user to the `/static/assets/chat.html` page.
          window.location.href = "/aichat/default";
        }
      });
    }
}

function ChatUtils() {

    this.checkInput = function(input) {
      const trimmedInput = input.trim();
      const inputWithoutLineBreaks = trimmedInput.replace(/(\r\n|\n|\r)/gm, '');

      if (inputWithoutLineBreaks.length === 0) {
        // this.createMessageAssistant("Invalid Input: Input length cannot be zero");
        return null;
      }
      return input;
    }

    this.createMessageAssistant = function(message) {
      message = message.replace(/(?:\r\n|\r|\n)/g, '<br>');
      $('.waiting').remove();
      var elem = $("#answer").find(".message").clone();
      $(elem).removeClass("hidden").find("p").empty().append("<div>" + message + "</div>");
      $("#chatbody").append(elem);
    }

    this.createMessageUser = function(message) {
      message = message.replace(/(?:\r\n|\r|\n)/g, '<br>');
      $('.waiting').remove();
      var elem = $("#question").find(".message").clone();
      $(elem).removeClass("hidden").find("p").empty().append("<div>" + message + "</div>");
      $("#chatbody").append(elem);
    }

    this.displayChatHistory = function(displayKey) {
      let interactiveChatHandler = new InteractiveChatHandler();

      const storedValue = localStorage.getItem(displayKey);
      if (storedValue) {
        try {
          const storedData = JSON.parse(storedValue);
          const subname = storedData.subname;
          const chatHistory = storedData.chatHistory;

          console.log("subname: " + subname);
          document.getElementById("subname").textContent = subname;

          if (Array.isArray(chatHistory)) {
            chatHistory.forEach(chat => {
              if (chat.author === "user") {
                this.createMessageUser(chat.content);
              } else if (chat.author === "assistant") {
                this.createMessageAssistant(chat.content);
              }
            });

            interactiveChatHandler.chatHistory = chatHistory;  
            interactiveChatHandler.currentKey = displayKey;

          } else {
            this.createMessageAssistant("チャット履歴が見つかりません");
          }
        } catch (e) {
          this.createMessageAssistant("チャット履歴の読み込みに失敗しました");
        }
      } else {
        this.createMessageAssistant("データが見つかりません");
      }
    }

    this.sentPostRequest = function(data, url2, onSuccess, onSuccessCallback) {
      var id = window.localStorage.getItem("id");
      var password = window.localStorage.getItem("password");
      $.ajax({
        url: url2,
        type: 'POST',
        data: JSON.stringify(data),
        contentType: 'application/json',
        headers: {
          "Authorization": "Basic " + btoa(id + ":" + password)
        },
        dataType: 'json',
        success: function(response) {
          if (onSuccess && typeof onSuccess === 'function') {
            if (onSuccessCallback != null) {
              onSuccess(response, onSuccessCallback);
            } else {
              onSuccess(response);
            }
          }
        },
        error: function(xhr) {
          if (xhr.status === 500 || xhr.status === 401 || xhr.status === 403) {
            var message = xhr.responseJSON ? JSON.parse(xhr.responseJSON).data.message : "エラーが発生しました";
            new ChatUtils().createMessageAssistant(message);
          } else {
            new ChatUtils().createMessageAssistant("エラーが発生しました、エラーが続く場合管理者へ問い合わせください");
          }
        }
      });
    }
}

function generateChatKey() {
  const now = new Date();
  const year = now.getFullYear();
  const month = ('0' + (now.getMonth() + 1)).slice(-2);
  const day = ('0' + now.getDate()).slice(-2);
  const hours = ('0' + now.getHours()).slice(-2);
  const minutes = ('0' + now.getMinutes()).slice(-2);
  const seconds = ('0' + now.getSeconds()).slice(-2);

  return `chat${year}${month}${day}:${hours}:${minutes}:${seconds}`;
}

function InteractiveChatHandler() {
  // インスタンスが既に存在する場合はそれを返す
  if (InteractiveChatHandler.instance) {
    return InteractiveChatHandler.instance;
  }

  // 初期化処理
  this.context = null;
  this.chatHistory = [];
  this.currentKey = null;

  // インスタンスを保存する
  InteractiveChatHandler.instance = this;

  this.addContext = function(context) {
    this.context = context;
  }

  this.addChat = function(content, author) {
    const chatMessage = { "content": content, "author": author };
    this.chatHistory.push(chatMessage);
  }

  this.addMessage = function(message, ichObject) {
    const author = "assistant";
    const content = message.response;
    const subname = document.getElementById("subname").textContent;

    ichObject.addChat(content, author);
    new ChatUtils().createMessageAssistant(message.response);

    // `this.currentKey` に修正
    if (this.currentKey) {
      console.log("in: " + this.currentKey);
    } else {
      console.log("in: not this.currentKey");
    }

    const newKey = generateChatKey();
    const saveData = {
      subname: subname,
      chatHistory: this.chatHistory
    };

    // `this.currentKey` に修正
    if (this.currentKey) {
      window.localStorage.removeItem(this.currentKey);  // `this.currentKey` に修正
      console.log("currentKey: " + this.currentKey);
    }

    this.currentKey = newKey;  // `currentKey` を `this.currentKey` に修正
    window.localStorage.setItem(newKey, JSON.stringify(saveData));
    localStorage.setItem('previousStoredKey', newKey);
  }

  this.getResponse = function(chat) {
    const url = "/api/gcppalm/chat";
    const author = "user";
    const chatData = {
      "prompt": chat,
      "context": this.context,
      "message_history": this.chatHistory
    };

    this.addChat(chat, author);
    new ChatUtils().sentPostRequest(chatData, url, this.addMessage.bind(this), this);
  }
}

// Static プロパティを設定する
InteractiveChatHandler.instance = null;

class QAEventHandler {
  static handleInteractiveUI(textareaText, context, eventobj) {
    $(eventobj).val('');
    let ch = new ChatUtils();
    if (ch.checkInput(textareaText) == null) {
      return;
    }
    var elem = $("#question").find(".message").clone();
    $(elem).removeClass("hidden").find("p").empty().append("<div>" + textareaText.replace(/\n/g, '<br/>') + "</div>");
    $("#chatbody").append(elem);

    var elem = $("#answer").find(".message").clone();
    $(elem).removeClass("hidden").addClass("waiting").find("p").text("回答を生成中です。しばらくお待ちください........");
    $(elem).find("p").append('<img src="/static/chat/assets/images/AI.gif" style="max-width:50px; max-height:50px;">');
    $("#chatbody").append(elem);
  }

  static handleQAevent() {
    var textarea_id_chat = "#interactivechattextbox";
    var contextarea_id = "#context";
    let interactiveChatHandler = new InteractiveChatHandler();

    $(textarea_id_chat).on('keydown', function(event) {
      if (event.keyCode === 13 && !event.shiftKey) {
        event.preventDefault();
        var textareaText = $(this).val();
        var context = $(contextarea_id).val();
        QAEventHandler.handleInteractiveUI(textareaText, context, this);
        interactiveChatHandler.addContext(context);
        interactiveChatHandler.getResponse(textareaText);
      }
    });
  }
}

(function ($) {
  "use strict";

  $('.slick-carousel').slick({
    slidesToShow: 5,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 2500,
    arrows: false,
    dots: false,
    responsive: [{
      breakpoint: 350,
      settings: {
        slidesToShow: 4,
      }
    }]
  });

  $('#submitbutton').click(function() {
    var e = jQuery.Event("keydown");
    e.which = 13;
    e.keyCode = 13;
    $("#interactivechattextbox").trigger(e);
  });

  QAEventHandler.handleQAevent();

  $("#login").click(function() {
    LoginHandler.handleLogin();
  });

})(jQuery);

$(document).on('click', '.chat-key-link', function(event) {
  event.preventDefault();
  const key = $(this).data('key');
  console.log("key:" + key);
  localStorage.setItem('displayKey', key);
  window.location.href = "/aichat/default";
});

window.onload = function() {
  const displayKey = localStorage.getItem('displayKey');
  let chatUtils = new ChatUtils();

  if (displayKey) {
    chatUtils.displayChatHistory(displayKey);
    currentKey = displayKey;  // グローバル変数 currentKey に設定
    localStorage.removeItem('displayKey');
  }
};
