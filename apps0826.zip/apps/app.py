from flask import Flask, request, render_template, redirect,jsonify,send_file
import logging
import json
from flask import abort, jsonify
# from apptools.pathtest import MyTest
from settings import StatusCode,Status
from apputils.authutil import AuthUtil

from apputils.chatutil import PageUtil

from apputils.menuhandler import LLMRequestor

# from dotenv import load_dotenv
# load_dotenv()
# if load_dotenv():  # 環境変数が設定されるとTrueを、そうでなければFalseを返す
#     print('environment variables were set from .env file')
# else:
#     print('environment variables were not set from .env file')

logging.basicConfig(level=logging.INFO,
                    format='%(asctime)s, %(levelname)-8s [%(filename)s:%(lineno)d] %(message)s')

app = Flask(__name__,static_url_path='/static', static_folder='static')
app.config['TEMPLATES_AUTO_RELOAD'] = True

class RequestProcessor:
    @staticmethod
    def create_response_message(status,status_code,message,response=None):
        if response==None:
            response=""

        response_message={
            "status":status,
            "status_code":status_code,
            "message":message,
            "response":response
        }
        return response_message
    
    @staticmethod
    def authorize():
        auth = request.authorization
        status=Status.ok
        try:
            if not auth or not AuthUtil.is_valid_user(auth.username, auth.password):
                status=Status.error
        except:
            logging.exception("An error occured while authorizing the user")
            status=Status.error
        
        if status==Status.error:
            status_code=StatusCode.auth_error
            message="User not authorized"
            return RequestProcessor.create_response_message(status,status_code,message)
        return None

    @staticmethod
    def check_input():
        status=Status.ok
        if not request.is_json:
            status=Status.error
            status_code=StatusCode.request_error
            message="Content-Type header must be application/json"
            return RequestProcessor.create_response_message(status,status_code,message)
        try:
            request_json=json.loads(request.data)
        except:
            logging.exception("Json is not valid")
            status=Status.error
            status_code=StatusCode.request_error
            message="JSON is not valid"
            return RequestProcessor.create_response_message(status,status_code,message)
        json_error=False
        if "prompt" not in request_json:
            json_error=True
        
        if "prompt" in request_json and len(request_json["prompt"].strip())==0:
            json_error=True
        
        if json_error:
            status=Status.error
            status_code=StatusCode.request_error
            message='Please include prompt in the message, eg. {"prompt":"Where is Tokyo?"}'
            return RequestProcessor.create_response_message(status,status_code,message)
        return None

@app.route('/', methods=['GET'])
def top_page():
    # return "Hello, World!bcd"
   return redirect("/aichat/default")
#    return render_template('techat.html')
    # return redirect("/static/chat/login.html", code=302)

@app.route("/techat")
def techat():
   return render_template('techat.html')

@app.route('/authorize', methods=['POST'])
def handle_authorization():
    #expected {"id";, "password"}, response={"result":"success/failed"}
    try:
        request_data=json.loads(request.data)
        id=request_data["id"]
        password=request_data["password"]
    except:
        logging.error("Authorizaion failed, bad json")
        return {"result":"failed"}
    try:
        if not AuthUtil.is_valid_user(id,password):
            logging.error("Authorization failed, wrong id and password")
            return {"result":"failed"}
    except:
        logging.error("Authorizatin failed, server internal error, error authorizing from secrets")
        return {"result":"failed"}
    
    return {"result":"success"}

@app.route('/aichat/<model>', methods=['GET'])
def handle_chat_pages(model):
    logging.info("Request received")
    logging.info(model)
    page_info=PageUtil.create_chat_page(model)
    if page_info==None:
        return "Page Not Found", 404
    context={
        "models":page_info["models"],
        "title":page_info["title"]
    }
    return render_template(page_info["template"],**context)

# @app.route('/download/',methods=['GET'])
# def handle_file_download():
#     filename=request.args.get("filename")
#     content=PageUtil.get_file_from_gcs(filename)
#     if content==None:
#         return "File Not Found", 404
#     download_filename=PageUtil.get_gcs_filename(filename)
#     return send_file(content, as_attachment=True, download_name=download_filename)

@app.route('/api/gcppalm/<model>', methods=['POST'])
def handle_prompt(model):
    logging.info("Request received")
    logging.info(model)
    authorization_status=RequestProcessor.authorize()
    if authorization_status!=None:
        return jsonify(authorization_status),403
    check_input=RequestProcessor.check_input()
    if check_input!=None:
        return jsonify(check_input),401
    
    try:
        prompt=json.loads(request.data)["prompt"]
        response=LLMRequestor.request_llm(prompt,model,json.loads(request.data))

        #handle enterprise search
        structured_response=""

        # if isinstance(response,dict):
        #     structured_response=response
        #     response=response["result"]

        status=Status.ok
        status_code=StatusCode.ok
        message="Request processed Successfully!"

        logging.info(message)
        # #write to bigquery
        # b=BigQueryUploader()
        # user=PageUtil.get_user_id(request)
        # b.insert_data_in_bigquery(prompt,response,model,user)
        resp=RequestProcessor.create_response_message(status,status_code,message,response)
        # resp["structured_response"]=structured_response

        return jsonify(resp), 200
        # return jsonify(response), 200
    

    except:
        status=Status.error
        status_code=StatusCode.internal_error
        message="An error occured while processing the request, please try again"
        logging.exception("An exception occured while fetching the request")
        return jsonify(RequestProcessor.create_response_message(status,status_code,message)), 500






if __name__ == '__main__':
    app.run(host='0.0.0.0',port=5000,debug=True)

