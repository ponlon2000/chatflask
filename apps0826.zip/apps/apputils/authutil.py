import json
import logging

class AuthUtil:

    @staticmethod
    def is_valid_user(username,password):
        # try:
        #     id_info=json.loads(AuthEnvironment().authentication_info)
        # except:
        #     logging.exception("Error fetching credentials from Secret Manager")
        #     return False
        
        # if username not in id_info:
        #     return False
        
        # if password!=id_info[username]:
        #     return False
        
        return True


        


