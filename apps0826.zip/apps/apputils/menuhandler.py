import logging
from apputils.environmenthandler import ExecutionEnvironment

import openai
from typing import List, Dict

from openai import AzureOpenAI


class LLMRequestor:
    @staticmethod
    def request_llm(prompt,model,jsondata):

        e=ExecutionEnvironment()
        projectid=e.project_id
        location=e.location
        model_path=None

        if model!=None:
            model_path=e.get_model_path(model)

        # vertexai.init(project=projectid, location=location)

        logging.info(prompt)
        logging.info(jsondata)

        #handle separately if it is chat
        if model.startswith("chat"):
            return LLMRequestor.request_chat_llm(prompt,jsondata,model)
        if model=="model1" or model=="model2":
            return LLMRequestor.request_chat_llm(prompt,jsondata,model)
        #model = TextGenerationModel.from_pretrained("text-bison@001")
        #use gemini pro as the default model
        return LLMRequestor.request_chat_llm(prompt,jsondata,model)
        #model = TextGenerationModel.from_pretrained("gemini-pro")
        #handle other models here
        #eg if model=="code" etc.
        #if no model is specified use default model.


    @staticmethod
    #prompt needs to be series of old chats
    #expected prompt, {"prompt":"prompt","message_history":[],"context":"context"}
    #message history format should be [{"content":"","author":"user/bot"},,]

    def request_chat_llm(prompt, jsondata,model):
        print(jsondata)

        # 初期メッセージの設定
        messages = [
            {"role": "system", "content": "あなたは優秀なAIアシスタントです"},
            {"role": "user", "content": prompt},
        ]

        # jsondataのmessage_historyをmessagesに追加
        for message in jsondata['message_history']:
            role = 'user' if message['author'] == 'user' else 'assistant'
            messages.append({"role": role, "content": message['content']})

        client = AzureOpenAI(
            api_key="32858a85c78947c6b4b18faea0e2bf8b",
            api_version="2024-05-01-preview",
            azure_endpoint="https://ais-chatbot-mine.openai.azure.com/"
        )
        
        try:
            response = client.chat.completions.create(
                model="model_gpt35turbo",
                messages=messages
            )


            # print(response)

            message_content = response.choices[0].message.content
            return message_content
            
            # return response

        except Exception as e:
            print(f"Error occurred: {e}")
            return None        

        # model = ChatModel.from_pretrained("chat-bison")
        # #handle other models here.
        # context=prompt["context"]
        
        # #cleanup context
        # context=PageUtil.remove_html_tags(context)
        # if len(context)>8000:
        #     context=context[0:8000]
        # logging.info(context)
        # message_history=[]
        # for message in prompt["message_history"]:
        #     content=message["content"]
        #     author=message["author"]
        #     chat_message=ChatMessage(content=content,author=author)
        #     message_history.append(chat_message)
        # session=ChatSession(
        # model=model,
        # context=context,
        # **parameters,
        # message_history=message_history
        # )
        # logging.info(prompt);
        # logging.info(prompt["prompt"])
        # r=session.send_message(prompt["prompt"])
        # logging.info("Chat result")
        # logging.info(r.text)
        # return r.text

    # @staticmethod
    # def request_chat_llm_mychatgpt_動作していない(prompt, model):
    #     openai.api_key = 'your key'

    #     # 初期メッセージの設定
    #     messages = [
    #         {"role": "system", "content": "あなたは優秀なAIアシスタントです。"},
    #         {"role": "user", "content": prompt},
    #     ]

    #     # OpenAIの新しいAPIを使用して応答を取得
    #     response = openai.ChatCompletion.create(
    #         model="gpt-3.5-turbo",
    #         messages=messages,
    #         temperature=0.7
    #     )

    #     # 応答メッセージを取得
    #     reply = response['choices'][0]['message']['content']
    #     return reply


    @staticmethod
    def parse_url(url):
        project_id = url.split('/')[5]
        location = url.split('/')[7]
        search_engine_id = url.split('/')[11]
        serving_config_id = url.split('/')[-1]
        return project_id,location,search_engine_id,serving_config_id


            
    

