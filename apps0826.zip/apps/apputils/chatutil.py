from settings import chat_pages,userid_header
import io
import os
import  apputils.environmenthandler as environmenthandler
import urllib.parse
import logging
import re

class PageUtil:

    @staticmethod
    def filter_search_results(search_results):
        filtered_results = []
        maximum_results=5
        for i in range(min(maximum_results, len(search_results))):
            result = search_results[i]
            result["snippet"]=""
            filtered_results.append(result)
        return filtered_results
    
    @staticmethod
    def concatenate_search_results(search_results,summary):
        concatenated=summary+"\n\n"
        concatenated+="回答ソース\n\n"
        for result in search_results:
            link=result["link"]
            concatenated+='<a href="{}">{}</a>'.format(link,link)+"\n"+"ページ"+str(result["page"])+"\n\n"
        return concatenated


    @staticmethod
    def create_chat_page(modelname):
        current_page=None
        for page in chat_pages:
            if page["name"]==modelname.strip():
                current_page=page
        #redirect to page not found error
        if current_page==None:
            return None
        page_data={
            "models":chat_pages,
            "title":current_page["title"],
            "template":current_page["template"]
        }
        return page_data
    
    @staticmethod
    def get_user_id(request):
        user_id="default"
        # Get the header value
        header_value = request.headers.get(userid_header)

        # Check if the header exists
        if header_value is None:
            return user_id

        # Urldecode the header value
        url_decoded_value = urllib.parse.unquote(header_value)

        user_id=url_decoded_value
        return user_id
    
    @staticmethod
    def if_contains_summary(summary):
        summary=summary.strip()
        contains_summary=False
        try:
            if len(summary) == len(summary.encode()):
                contains_summary=False
            else:
                contains_summary=True
        except UnicodeDecodeError:
            contains_summary=True
        logging.info(summary)
        logging.info(contains_summary) 
        return contains_summary

    @staticmethod
    def remove_html_tags(text):
        """
        This function removes all HTML tags from a string.

        Args:
            text: The string to remove HTML tags from.

        Returns:
            The string with all HTML tags removed.
        """
        clean_text = re.sub(r'<[^>]*>', '', text)
        return clean_text

    # @staticmethod
    # def convert_link(link):
    #     e=environmenthandler.ExecutionEnvironment()
    #     serving_hostname=e.serving_hostname
    #     boxgcsmap=e.get_box_mapping()
    #     print(boxgcsmap)
    #     if link in boxgcsmap:
    #         return boxgcsmap[link]
    #     link="https://{}/download/?filename={}".format(serving_hostname,link)
    #     return link   


    # @staticmethod
    # def get_gcs_filename(filename):
    #     if filename==None:
    #         return None
    #     file_name = urllib.parse.urlparse(filename).path.lstrip("/")
    #     file_name=file_name.split('/')[-1]
    #     return file_name
    
    # #returns None if there is some error
    # @staticmethod
    # def get_file_from_gcs(filename):
    #     content=None
    #     # Create a storage client.
    #     client = storage.Client()
        
    #     bucket_name = urllib.parse.urlparse(filename).netloc
    #     object_name = urllib.parse.urlparse(filename).path.lstrip("/")
        
    #     logging.info(bucket_name,object_name)

    #     try:
    #     # Get the bucket object.
    #         bucket = client.bucket(bucket_name)
    #         object = bucket.blob(object_name)
    #         gcs_filename=PageUtil.get_gcs_filename(filename)
    #         logging.info(gcs_filename)
    #         temp_file_path = f'/tmp/{gcs_filename}'
    #         object.download_to_filename(temp_file_path)
    #         content=temp_file_path

    #     except:
    #         logging.exception("Error reading file from the bucket")
    #     return content


    
