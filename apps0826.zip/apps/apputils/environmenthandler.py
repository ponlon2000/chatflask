import os
from settings import boxgcsmapping_env,llm_routing_map_env,project_id_env,bigquery_dataset_env,bigquery_table_name_env,location_env, project_name_env,serving_hostname_env

# class SecretManagerHandler:

    # @staticmethod
    # def fetch_secret(secret_id):
    #     """Fetches a secret from Secret Manager."""

    #     client = secretmanager.SecretManagerServiceClient()
    #     name = client.secret_path(ExecutionEnvironment().project_id, secret_id)
    #     for version in client.list_secret_versions(request={"parent": name}):
    #         latest=version.name
    #         break
    #     response = client.access_secret_version(name=latest)
    #     return response.payload.data.decode('UTF-8')


class AuthEnvironment:

    def __init__(self):
        self.authentication_info=None
        # self.fetch_execution_environment()
    
    # def fetch_execution_environment(self):
    #     self.authentication_info=ExecutionEnvironmentUtil.get_authentication_info()

class ExecutionEnvironment:

    def __init__(self):
        self.boxgcsmapping=None
        self.llm_routing_map=None
        self.project_id=None
        self.project_name=None
        self.bigquery_table_name=None
        self.bigquery_dataset=None
        self.location=None
        self.serving_hostname=None
        self.boxmap=None

    #     self.fetch_execution_environment()

    # def fetch_execution_environment(self):
    #     self.boxgcsmapping,self.llm_routing_map,self.project_id,self.bigquery_table_name,self.bigquery_dataset,self.location,self.project_name,self.serving_hostname=ExecutionEnvironmentUtil.get_cloud_run_environment()

    
    # def get_box_mapping(self):
    #     csvcontent=LLMUtil.read_text_file_from_gcs(self.boxgcsmapping)
    #     csvlines=LLMUtil.read_csv_text(csvcontent)
    #     boxgcsmap=LLMUtil.create_csv_dict(csvlines)
    #     self.boxmap=boxgcsmap
    #     return self.boxmap

    def get_model_path(self,modelid):
            return None


        # llm_routing_map=json.loads(self.llm_routing_map)
        # if modelid not in llm_routing_map:
        #     return None
        # if llm_routing_map[modelid]==None:
        #     return None
        # if len(llm_routing_map[modelid].strip())==0:
        #     return None
        
        # return llm_routing_map[modelid].strip()

class ExecutionEnvironmentUtil:

    # @staticmethod
    # def get_authentication_info():
    #     authentication_info=SecretManagerHandler.fetch_secret(authorization_secret_id)
    #     return authentication_info
    
    @staticmethod
    def get_cloud_run_environment():
        #get llm_routing_map
        llm_routing_map=os.environ.get(llm_routing_map_env)

        #get project id
        project_id=os.environ.get(project_id_env)

        #get bigquery table name
        bigquery_table_name=os.environ.get(bigquery_table_name_env)

        #get bigquery dataset name
        bigquery_dataset=os.environ.get(bigquery_dataset_env)

        location=os.environ.get(location_env)

        #get project name
        project_name=os.environ.get(project_name_env)

        #serving_env
        serving_hostname=os.environ.get(serving_hostname_env)

        #boxgcs mapping
        boxgcsmapping=os.environ.get(boxgcsmapping_env)

        return boxgcsmapping,llm_routing_map,project_id,bigquery_table_name,bigquery_dataset,location,project_name,serving_hostname







