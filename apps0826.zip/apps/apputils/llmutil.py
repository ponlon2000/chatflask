import io
import os
import logging
import requests
import time

class LLMUtil:

      
    @staticmethod
    def get_bucket_path(gcs_filepath):
        import re
        # Extract bucket name and filepath using regular expression
        match = re.match(r"gs://([^/]+)/(.*)", gcs_filepath)
        if match:
            bucket_name = match.group(1)
            filepath = match.group(2)
            return bucket_name,filepath
        else:
            return None
    
    @staticmethod
    def read_csv_text(csv_text):
        #read csv content from string
        import csv
        reader = csv.reader(csv_text.splitlines(), delimiter=',')
        return list(reader)
    
    
    #takes list of csv lines as input, each csv line is also a list
    #create a dict that contains second element of the list as key and 3rd element as value
    @staticmethod
    def create_csv_dict(csv_lines):
        csv_dict = {}
        for line in csv_lines:
            csv_dict[line[2].strip()] = line[3].strip()
        return csv_dict
        
    # @staticmethod
    # def read_text_file_from_gcs(filepath):
    #     """Reads a text file from Google Cloud Storage and returns its content as UTF-8 text.

    #     Args:
    #         filepath (str): The Google Cloud Storage file path (e.g., gs://bucket-name/file-path.txt).

    #     Returns:
    #         str: The UTF-8 encoded content of the file.
    #     """

    #     client = storage.Client()
    #     bucket_name, file_path = LLMUtil.get_bucket_path(filepath)  # Extract bucket and file path
    #     bucket = client.get_bucket(bucket_name)
    #     blob = bucket.blob(file_path)

    #     with io.BytesIO() as file_buffer:
    #         blob.download_to_file(file_buffer)
    #         file_buffer.seek(0)  # Rewind the buffer for reading
    #         return file_buffer.read().decode("utf-8")  # Decode as UTF-8
        
    # @staticmethod    
    # def get_extractive_content(content_type,data_items):
    #     results={"content_type":None,"pageno":None,"content":None,"link":None}
    #     content=""
    #     pageno=""
    #     link=""
    #     logging.error(data_items)
    #     for item in data_items:
    #         if item[0]=="link":
    #             link=item[1]
    #         if item[0]==content_type:
    #             for ext_answers in item[1]:
    #                 for ext_answers_item in ext_answers.items():
    #                     data=ext_answers_item
    #                     if data[0]=="content":
    #                         content=data[1]
    #                     if data[0]=="pageNumber":
    #                         pageno=data[1]
    #     results["content_type"]=content_type
    #     results["content"]=content
    #     results["pageno"]=pageno
    #     results["link"]=link
    #     return results

    # @staticmethod
    # def get_snippets(data_items):
    #     results={"content_type":None,"pageno":None,"content":None,"link":None}
    #     for item in data_items:
    #         if item[0]=="link":
    #             link=item[1]
            
    #         if item[0]=="snippets":
    #             content_type="snippets"
    #             for ext_answers in item[1]:
    #                 for ext_answers_item in ext_answers.items():
    #                     data=ext_answers_item
    #                     if data[0]=="snippet":
    #                         content=data[1]
    #     results["content_type"]=content_type
    #     results["content"]=content
    #     #results["pageno"]=pageno
    #     results["link"]=link
    #     return results
    
    @staticmethod
    def create_context(answers):
        logging.error(answers)
        context=""
        answer_keys=["snippets","extractive_answers","extractive_segments"]
        for answer_key in answer_keys:
            for answer in answers[answer_key]:
                content=answer["content"]
                context+=content+"\n\n"
        return context


    @staticmethod
    def extract_filename(file_path):
        """Extracts the filename from a file path.

        Args:
            file_path: The file path to extract the filename from.

        Returns:
            The filename.

        """

        return os.path.basename(file_path)
    
    # @staticmethod
    # def get_citations(answers):
    #     extractive_answers=answers["extractive_answers"]
    #     max_answers=1
    #     extractive_answers=extractive_answers[0:max_answers]
    #     source_information=""
    #     for response in extractive_answers:
    #         link=response["link"]
    #         if link==None:
    #             continue
    #         filename=LLMUtil.extract_filename(link)
    #         link=PageUtil.convert_link(link)
    #         page=response["pageno"]
    #         #link=link.replace("gs://","https://storage.cloud.google.com/")
    #         answer_line=f'''{filename} <a href="{link}"> {link}</a> (ページ{page})\n'''
    #         source_information+=answer_line 
    #     return source_information       

