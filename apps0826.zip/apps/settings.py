# -*- coding: utf-8 -*-

class StatusCode:
    ok="200"
    request_error="401"
    auth_error="403"
    internal_error="500"

class Status:
    ok="OK"
    error="ERROR"

#secret id
authorization_secret_id="authorization"

#environment variables
llm_routing_map_env="llm_routing_map"
project_id_env="project_id"
project_name_env="project_name"
bigquery_table_name_env="bigquery_table"
bigquery_dataset_env="bigquery_dataset"
location_env="location"
serving_hostname_env="serving_hostname"
boxgcsmapping_env="boxgcsmapping"

logourl="https://www.xxxx.com/images/yyyy.png"

#userid header location
userid_header="x-vertexai-userid"

#Palm2 Parameters
parameters = {
    "temperature": 0.2,
    "max_output_tokens": 1000,
    "top_p": 0.8,
    "top_k": 40
}

#gemini parameters
gemini_parameters={
                "max_output_tokens": 2048,
                "temperature": 0.1,
                "top_p": 1,
                "top_k": 40
            }

chat_pages=[
    {
        "name":"default",
        "display_name":"GPT-3.5-Turbo",
        "title":"Q&Aボット",
        "template":"techat.html",
        "link":"/aichat/default"
    },
    {
        "name":"chat",
        "display_name":"GPT-3.5-Turbo2",
        "title":"AIチャットボット",
        "template":"techat.html",
        "link":"/aichat/chat"
    },
    {
        "name":"model1",
        "display_name":"name_model1",
        "title":"資料検索",
        "template":"chat.html",
        "link":"/aichat/model1"
    },
    {
        "name":"model2",
        "display_name":"name_model2",
        "title":"サイト検索",
        "template":"chat.html",
        "link":"/aichat/model2"
    }

]


#table schema
'''
tablename: response

date: TimeStamp
prompt: String
response: String
model: String 
user:String
'''
